from flask import Flask
from flask import request, render_template
import json
# from predict import predict
from fuzzywuzzy import fuzz

from coarse2fine.wikisql.eval_trans import eval_init, evaluate

app = Flask(__name__)
app.debug = False

# model loading ---------------------------------------------------------------------------
print('Loading model1--------------')
translator = eval_init()
print('Done loading1----------------')

def predict(question, table_id):
    with open('jsons/annotated.json', 'r') as f:
        anno_data = json.load(f)
    questions_data = anno_data[table_id]
    m = 0
    idx = -1
    for q in range(len(questions_data)):
        temp_ = fuzz.partial_ratio(question, ' '.join(questions_data[q]['question']['words']))
        if  m < temp_:
            m = temp_
            idx = q
    final_anno = questions_data[idx]
    words = questions_data[idx]['question']['words']
    # print(questions_data[q].words, question)
    with open('./coarse2fine/data_model/wikisql/annotated_ent/test.jsonl', 'w') as f:
        json.dump(final_anno, f)
    # sys("python ./coarse2fine/wikisql/evaluate.py -split 'test' -data_path './coarse2fine/data_model/wikisql/' -model_path './coarse2fine/wikisql/m_34.pt'")
    evaluate(translator)
    with open('predictions.json', 'r') as f:
        predictions = json.load(f)
    with open('jsons/headers.json', 'r') as f:
        header = json.load(f)[table_id]
    agg_ops = ['', 'MAX', 'MIN', 'COUNT', 'SUM', 'AVG']
    cond_ops = ['=', '>', '<', 'OP']
    print('predictions:', predictions)
    predictions = predictions[0]

    predictions['agg'] = agg_ops[predictions['agg']]
    predictions['sel'] = header[predictions['sel']]
    cond_str_list = []
    for cond in predictions['cond']:
        temp = [header[cond[0]], cond_ops[cond[1]],"'" + " ".join([words[i] for i in range(cond[2][0], cond[2][1] + 1)]) + "'"]
        cond_str_list.append(" ".join(temp))
    print("cond list:", cond_str_list)
    cond_str = " AND ".join(cond_str_list)
    sql = "SELECT {}({}) FROM {} WHERE {}".format(predictions['agg'], predictions['sel'], table_id, cond_str)
    return (sql, header)

# model loading ends ----------------------------------------------------------------------

@app.route("/")
def index():
    with open('jsons/headers.json', 'r') as f:
        tables = json.load(f)
    with open('jsons/table_names.json', 'r') as f:
        names = json.load(f)
    context = {
        'tables': [{'id': tab, 'header': tables[tab], 'name': names[tab]} for tab in tables.keys()],
    }
    return render_template('index.html', context=context)

@app.route("/results", methods=['POST'])
def result():
    question = request.form['question']
    table_id = request.form['id']
    prediction, header = predict(question, table_id)
    context = {
        'prediction': prediction,
        'header': header,
        'question': question
    }
    return render_template('result.html', context=context)

@app.route("/table/<string:table_id>")
def table_id(table_id):
    with open('jsons/questions.json', 'r') as f:
        data = json.load(f)
    with open('jsons/table_names.json', 'r') as f:
        names = json.load(f)
    context = {
        'name': names[table_id],
        'id': table_id,
        'questions': data[table_id]
    }
    return render_template('questions.html', context=context)

app.run(host='0.0.0.0')