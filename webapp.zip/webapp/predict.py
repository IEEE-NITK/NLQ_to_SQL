import json
from fuzzywuzzy import fuzz
from os import system as sys

def predict(question, table_id):
    with open('jsons/annotated.json', 'r') as f:
        anno_data = json.load(f)
    questions_data = anno_data[table_id]
    m = 0
    idx = -1
    for q in range(len(questions_data)):
        temp_ = fuzz.partial_ratio(question, ' '.join(questions_data[q]['question']['words']))
        if  m < temp_:
            m = temp_
            idx = q
    final_anno = questions_data[idx]
    words = questions_data[idx]['question']['words']
    # print(questions_data[q].words, question)
    with open('./coarse2fine/data_model/wikisql/annotated_ent/test.jsonl', 'w') as f:
        json.dump(final_anno, f)
    sys("python ./coarse2fine/wikisql/evaluate.py -split 'test' -data_path './coarse2fine/data_model/wikisql/' -model_path './coarse2fine/wikisql/m_34.pt'")
    with open('predictions.json', 'r') as f:
        predictions = json.load(f)
    with open('jsons/headers.json', 'r') as f:
        header = json.load(f)[table_id]
    agg_ops = ['', 'MAX', 'MIN', 'COUNT', 'SUM', 'AVG']
    cond_ops = ['=', '>', '<', 'OP']
    print('predictions:', predictions)
    predictions = predictions[0]

    predictions['agg'] = agg_ops[predictions['agg']]
    predictions['sel'] = header[predictions['sel']]
    cond_str_list = []
    for cond in predictions['cond']:
        temp = [header[cond[0]], cond_ops[cond[1]],"'" + " ".join([words[i] for i in range(cond[2][0], cond[2][1] + 1)]) + "'"]
        cond_str_list.append(" ".join(temp))
    print("cond list:", cond_str_list)
    cond_str = " AND ".join(cond_str_list)
    sql = "SELECT {}({}) FROM {} WHERE {}".format(predictions['agg'], predictions['sel'], table_id, cond_str)
    return (sql, header)
