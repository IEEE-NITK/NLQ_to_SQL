from __future__ import division
from builtins import bytes
import os
import argparse
import math
import codecs
import torch

from coarse2fine.wikisql import table
from coarse2fine.wikisql.table import IO
from coarse2fine.wikisql import opts
from itertools import takewhile, count
try:
    from itertools import zip_longest
except ImportError:
    from itertools import izip_longest as zip_longest
from path import Path
import glob
import json
from tqdm import tqdm
from coarse2fine.wikisql.lib.dbengine import DBEngine
from coarse2fine.wikisql.lib.query import Query

parser = argparse.ArgumentParser(description='evaluate.py')
opts.translate_opts(parser)
opt = parser.parse_args()
torch.cuda.set_device(opt.gpu)
opt.anno = './coarse2fine/data_model/wikisql/annotated_ent/test.jsonl'
opt.source_file = './coarse2fine/data_model/wikisql/data/test.jsonl'
opt.db_file = './coarse2fine/data_model/wikisql/data/test.db'
opt.pre_word_vecs = './coarse2fine/data_model/wikisql/embedding'
opt.model_path = './coarse2fine/wikisql/m_34.pt'

def eval_init():

    dummy_parser = argparse.ArgumentParser(description='train.py')
    opts.model_opts(dummy_parser)
    opts.train_opts(dummy_parser)
    dummy_opt = dummy_parser.parse_known_args([])[0]

    # with codecs.open(opt.source_file, "r", "utf-8") as corpus_file:
    #     sql_list = [json.loads(line)['sql'] for line in corpus_file]

    # js_list = table.IO.read_anno_json(opt.anno)       ------

    # prev_best = (None, None)
    for fn_model in glob.glob(opt.model_path):
        print('model:',fn_model)
        print('anno:',opt.anno)
        opt.model = fn_model

        translator = table.Translator(opt, dummy_opt.__dict__)
        # data = table.IO.TableDataset(js_list, translator.fields, None, False)
        # test_data = table.IO.OrderedIterator(
            # dataset=data, device=opt.gpu, batch_size=opt.batch_size, train=False, sort=True, sort_within_batch=False)

        # inference
        # r_list = []
        # for batch in test_data:
        #     r_list += translator.translate(batch)
        # r_list.sort(key=lambda x: x.idx)
    return translator

def evaluate(translator):
    # global translator
    js_list = table.IO.read_anno_json(opt.anno)
    data = table.IO.TableDataset(js_list, translator.fields, None, False)
    test_data = table.IO.OrderedIterator(dataset=data, device=opt.gpu, batch_size=opt.batch_size, train=False, sort=True, sort_within_batch=False)
    for batch in test_data:
        translator.translate(batch)